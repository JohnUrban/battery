#!/usr/bin/env bash
set -e

if [ $# -eq 0 ]; then 
echo "
------------------------------------------------------------------------------
   Requires single argument:

	./install-battery-reapr.sh /path/to/alreadyInstalled/BamToolsRootDir

	This will be used as the BAMTOOLS_ROOT variable in src/Makefile
	- Should be absolute path 
------------------------------------------------------------------------------
"
exit
fi

USER_PROVIDED_BAMTOOLS=${1}

rootdir=$PWD

unamestr=$(uname)

# Check if the OS seems to be Linux. This should be informative to
# Windows/Mac users that are trying to install this, despite it being
# developed for Linux. There is a VM avilable for Mac/Windows.
if [ "$unamestr" != "Linux" ]
then
    echo "Operating system does not appear to be Linux: uname says it's '$unamestr'"
    echo "If you're using a Mac or Windows, then the recommended way to run REAPR is to use the virtual machine."
    echo "REAPR installation may have trouble."
    echo "Forcing: carrying on anyway. Best of luck to you..."
fi


echo "------------------------------------------------------------------------------
                           Checking prerequisites for REAPR
------------------------------------------------------------------------------
"
echo "Checking Perl modules..."

modules_ok=1

for module in File::Basename File::Copy File::Spec File::Spec::Link Getopt::Long List::Util
do
    set +e
    perl -M$module -e 1 2>/dev/null

    if [ $? -eq 0 ]
    then
        echo "  OK $module"
    else
        echo "  NOT FOUND: $module"
        modules_ok=0
    fi
    set -e
done

if [ $modules_ok -ne 1 ]
then
    echo "Some Perl modules were not found - please install them. Cannot continue"
    exit 1
else
    echo "... Perl modules all OK"
fi


echo
echo "Looking for R..."

if type -P R
then
    echo "... found R OK"
else
    echo "Didn't find R. It needs to be installed and in your path. Cannot continue"
fi


cd third_party

echo "
------------------------------------------------------------------------------
                              Compiling Tabix (packaged with REAPR)
------------------------------------------------------------------------------
"
cd tabix
make
cd ..
echo "
------------------------------------------------------------------------------
                              Tabix compiled (packaged with REAPR)
------------------------------------------------------------------------------
"

echo "
------------------------------------------------------------------------------
                             Compiling snpomatic (packaged with REAPR)
------------------------------------------------------------------------------
"
cd snpomatic
make
cd ..
echo "
------------------------------------------------------------------------------
                              snpomatic compiled (packaged with REAPR)
------------------------------------------------------------------------------
"

echo "
------------------------------------------------------------------------------
                             Compiling samtools (packaged with REAPR)
------------------------------------------------------------------------------
"
cd samtools
make
echo "
------------------------------------------------------------------------------
                              samtools compiled (packaged with REAPR)
------------------------------------------------------------------------------
"

echo "
------------------------------------------------------------------------------
                               Compiling Reapr 
------------------------------------------------------------------------------
"
cd $rootdir/src
make BAMTOOLS_ROOT=${USER_PROVIDED_BAMTOOLS}
cd ..
ln -s src/reapr.pl reapr
echo "
Reapr compiled

All done!

Run
./reapr
for usage.

Read the manual
manual.pdf
for full instructions
"

