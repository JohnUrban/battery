#!/usr/bin/env python3
# coding: utf-8
"""

Copyright (c) 2016-2017, Evgeny Zdobnov (ez@ezlab.org)
Licensed under the MIT license. See LICENSE.md file.

"""
__version__ = "3.0.1"
