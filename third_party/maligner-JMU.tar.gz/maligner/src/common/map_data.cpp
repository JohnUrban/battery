#include "map_data.h"

namespace maligner_maps {

  // int MapData::num_copies = 0;
  // int MapData::num_constructs = 0;
  
}
