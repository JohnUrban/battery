#define PACKAGE_VERSION "0.4"
#define AUTHOR "Lee Mendelowitz" 
#define AUTHOR_EMAIL "lmendelo@umiacs.umd.edu"