#include <iostream>
#include <ostream>
#include <string>
#include <vector>

#include "score_matrix_vd.h"
#include "score_matrix_profile.h"
#include "align.h"


// using maligner_dp::Chi2SizingPenalty;
// using maligner_dp::AlignTask;
// using maligner_dp::AlignOpts;

namespace maligner_vd {



}