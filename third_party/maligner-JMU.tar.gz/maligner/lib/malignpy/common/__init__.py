from wrap_file_function import *
from dict_wrap import DictWrap