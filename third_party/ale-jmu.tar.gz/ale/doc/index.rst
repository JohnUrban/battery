.. ALE documentation master file, created by
   sphinx-quickstart on Fri Dec 16 21:11:32 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ALE's documentation!
===============================

.. toctree::
   :maxdepth: 2
   
   install
   plotter3
   synthReadGen
   artificial_errors
   image_maker

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
